//
//  constants.h
//  TCP2
//
//  Created by Francesco on 4/2/15.
//  Copyright (c) 2015 FrancescoAgosti. All rights reserved.
//


#define MAX_PACKET_SIZE 512
#define DATA_PACKET_METADATA_LENGTH 12
#define ACK_PACKET_LENGTH 8
#define MAX_PACKET_DATA_SIZE 500
